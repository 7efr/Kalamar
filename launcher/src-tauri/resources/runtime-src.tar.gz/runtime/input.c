// Host input for nn::hid (runtime/ov_input.c): an SDL3 gamepad (no SDL window needed), the keyboard and the mouse,
// merged into Switch npad button bits and stick axes. Button order follows libnx HidNpadButton (ISC). The key and pad
// bindings are the tables in input_map.c (totk.ini overrides them). The keyboard and the mouse come from the window
// system's back end (input_wsys.h: input_win.c with Win32, input_sdl.c with SDL), which also owns the cursor capture.
// Keys and their map: docs/controls.md.
// The gamepad also rumbles (input_rumble) and, when it has a gyro and an accelerometer, feeds the six-axis sensor from a
// thread of its own (input_motion_start). Every SDL call on the gamepad is made under `lock`.
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <SDL3/SDL.h>

#include "cfg.h"
#include "host.h"
#include "input.h"
#include "input_map.h"
#include "input_wsys.h"
#include "mgyro_bench.h"
#include "mouse_gyro.h"
#include "nvn_api.h"
#include "scene_start.h"
#include "ui/menu.h"
#include "vk.h"
#include "platform/platform.h"

enum { STICK_MAX = 32767, STICK_DIR = 16384, TRIGGER_ON = 16384, RESCAN_MS = 1000 };

static PlatMutex lock = PLAT_MUTEX_INIT;
static int state;                    // 0 not started, 1 running, -1 disabled or SDL failed
static volatile int32_t g_block, g_menu;   // text entry / host menu: 0 off, 1 open, 2 waiting for release
// The device the player used last (input_kbm_last): 1 keyboard and mouse, 0 the gamepad. A pad counts once a button is
// down or a stick is past half way (a drifting stick never switches), the mouse once it moved MOUSE_USED raw counts
// within one poll (a slow deliberate move does; a desk bump does not), the keyboard with any key or mouse button.
enum { PAD_USED = 16384, MOUSE_USED = 6 };
static volatile int32_t g_kbm_last = 1;
int input_kbm_last(void) { return __atomic_load_n(&g_kbm_last, __ATOMIC_RELAXED); }
static SDL_Gamepad *pad;
static uint64_t next_scan;
static int pad_rumble;               // the open gamepad has rumble motors
static volatile int32_t pad_labels[4];  // ... and the labels of its south, east, west, north buttons (PAD_LABEL_*), any thread
static int pad_east_a;               // ... and labels its east face button A (Nintendo layout under TOTK_PAD_LAYOUT=auto)
static int pad_layout = -1;          // PAD_LAYOUT_* in effect for the open gamepad, -1 to pick again; live (cfg_version)
static unsigned pad_layout_seen;
static volatile int32_t pad_layout_shown = -1;   // pad_layout for the menu (any thread), -1 without a gamepad
static SDL_JoystickID sensor_pad;    // the gamepad whose sensors the motion thread set up, 0 none
static int sensor_ok;                // ... and it has both sensors, enabled
static int motion_thread;            // 0 not started, 1 running, -1 off (TOTK_MOTION=0, no SDL)
static volatile int32_t mg_recenter_req, mg_restart_req;   // mouse gyro (mouse_gyro_tick): level it / start it over
static volatile int32_t pad_gyro_live;                     // the open gamepad's sensors feed motion_global()

// SDL buttons of the gamepad inputs (input_map.h PAD_*), by position; PAD_ZL and PAD_ZR are the triggers (axes).
static const SDL_GamepadButton pad_sdl[PAD_COUNT] = {
    [PAD_SOUTH] = SDL_GAMEPAD_BUTTON_SOUTH, [PAD_EAST] = SDL_GAMEPAD_BUTTON_EAST, [PAD_WEST] = SDL_GAMEPAD_BUTTON_WEST,
    [PAD_NORTH] = SDL_GAMEPAD_BUTTON_NORTH, [PAD_LSTICK] = SDL_GAMEPAD_BUTTON_LEFT_STICK,
    [PAD_RSTICK] = SDL_GAMEPAD_BUTTON_RIGHT_STICK, [PAD_L] = SDL_GAMEPAD_BUTTON_LEFT_SHOULDER,
    [PAD_R] = SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER, [PAD_START] = SDL_GAMEPAD_BUTTON_START, [PAD_BACK] = SDL_GAMEPAD_BUTTON_BACK,
    [PAD_DPAD_LEFT] = SDL_GAMEPAD_BUTTON_DPAD_LEFT, [PAD_DPAD_UP] = SDL_GAMEPAD_BUTTON_DPAD_UP,
    [PAD_DPAD_RIGHT] = SDL_GAMEPAD_BUTTON_DPAD_RIGHT, [PAD_DPAD_DOWN] = SDL_GAMEPAD_BUTTON_DPAD_DOWN,
    [PAD_LPADDLE1] = SDL_GAMEPAD_BUTTON_LEFT_PADDLE1, [PAD_RPADDLE1] = SDL_GAMEPAD_BUTTON_RIGHT_PADDLE1,
    [PAD_LPADDLE2] = SDL_GAMEPAD_BUTTON_LEFT_PADDLE2, [PAD_RPADDLE2] = SDL_GAMEPAD_BUTTON_RIGHT_PADDLE2,
};

// TOTK_INPUT_SCRIPT=<file>: lines "<frame> <button> [hold]" or "<frame> LSTICK|RSTICK <x> <y> [hold]", ORed into the real input.
// <frame> and its hold are 60 Hz ticks of game time since the first present (frame_step_ticks: presents at 60 fps), so
// the title menus get the presses at the same game time at any frame limit. A line "@<ms> ..." is timed instead: <ms>
// and its hold are milliseconds of the world clock (frame_step_world_us, game time since the loaded save's first
// frame), so it lands at the same game time at any frame rate and load length. A timed event shorter than a frame is
// applied once. In a script with timed lines (a recording) the untimed ones belong before the world clock: they stop
// when it starts, as the load ends at another tick in each run.
// at, hold: ticks, or microseconds of the world clock when timed.
typedef struct { uint64_t at, hold; int bit, stick, timed; int32_t x, y; int logged; char text[48]; } ScriptEv;
static const struct { const char *name; int bit; } script_buttons[] = {
    {"A", B_A}, {"B", B_B}, {"X", B_X}, {"Y", B_Y}, {"LCLICK", B_STICK_L}, {"RCLICK", B_STICK_R}, {"L", B_L}, {"R", B_R},
    {"ZL", B_ZL}, {"ZR", B_ZR}, {"PLUS", B_PLUS}, {"MINUS", B_MINUS}, {"LEFT", B_LEFT}, {"UP", B_UP}, {"RIGHT", B_RIGHT}, {"DOWN", B_DOWN},
};
static ScriptEv *script_ev;
static int script_n, script_state;   // 0 not loaded, 1 loaded
static int script_mixed;             // the script has timed lines: its untimed ones end where the world clock starts
static int32_t script_mouse[2];      // one-shot raw counts, consumed by the camera hook; under lock

static int script_cap;

// One script line into *e: 1 if it is an event, 0 for a blank or comment line, -1 (logged) for a malformed one.
static int script_parse(const char *line, int ln, ScriptEv *e) {
    char name[32];
    double at;
    int off = 0, timed = line[0] == '@';
    if (sscanf(line + timed, "%lf %31s%n", &at, name, &off) < 2 || at < 0) return 0;
    off += timed;
    double unit = timed ? 1000.0 : 1.0;   // ms to us, or presents
    *e = (ScriptEv){.at = (uint64_t)(at * unit + 0.5), .hold = timed ? 66667 : 4, .bit = -1, .timed = timed};
    long a, b;
    double c;
    if (!strcmp(name, "MOUSE") || !strcmp(name, "LSTICK") || !strcmp(name, "RSTICK")) {
        int n = sscanf(line + off, "%ld %ld %lf", &a, &b, &c);
        if (n < 2) { rt_log("input: script line %d: %s needs x y [hold]", ln, name); return -1; }
        e->stick = name[0] == 'M' ? 3 : name[0] == 'L' ? 1 : 2; e->x = (int32_t)a; e->y = (int32_t)b;
        if (e->stick == 3) e->hold = 1;   // a displacement, never a held speed
        if (n >= 3 && c > 0) e->hold = (uint64_t)(c * unit + 0.5);
        snprintf(e->text, sizeof e->text, "%s %d %d", name, e->x, e->y);
    } else {
        for (size_t i = 0; i < sizeof script_buttons / sizeof *script_buttons; i++)
            if (!strcmp(name, script_buttons[i].name)) e->bit = script_buttons[i].bit;
        if (e->bit < 0) { rt_log("input: script line %d: unknown button %s", ln, name); return -1; }
        if (sscanf(line + off, "%lf", &c) == 1 && c > 0) e->hold = (uint64_t)(c * unit + 0.5);
        snprintf(e->text, sizeof e->text, "%s", name);
    }
    return 1;
}

static int script_push(const ScriptEv *e) {
    if (script_n == script_cap) {
        int cap = script_cap ? script_cap * 2 : 32;
        ScriptEv *p = realloc(script_ev, (size_t)cap * sizeof *script_ev);
        if (!p) return 0;
        script_ev = p, script_cap = cap;
    }
    script_ev[script_n++] = *e;
    return 1;
}

static void script_load(void) {
    script_state = 1;
    const char *path = cfg_get("TOTK_INPUT_SCRIPT");
    if (!path || !*path) return;
    FILE *f = fopen(path, "r");
    if (!f) { rt_log("input: cannot open TOTK_INPUT_SCRIPT %s", path); return; }
    char line[256];
    int ln = 0;
    while (fgets(line, sizeof line, f)) {
        ln++;
        char *h = strchr(line, '#');
        if (h) *h = 0;
        ScriptEv e;
        if (script_parse(line, ln, &e) <= 0) continue;
        if (!script_push(&e)) { script_n = 0; fclose(f); return; }
        script_mixed |= e.timed;
    }
    fclose(f);
    rt_log("input: script %s, %d events", path, script_n);
}

// TOTK_INPUT_LIVE=<file>: a test driver's script, read while the game runs (a harness steers one or more instances
// without window focus and looks at what they show). Lines appended to the file count from the tick they are read at:
// "[+<ticks>] <button> [hold]" and "[+<ticks>] LSTICK|RSTICK|MOUSE <x> <y> [hold]" as in TOTK_INPUT_SCRIPT, and
// "SHOT <path.png>" saves the next presented frame at full size (rt_shot_request). The file is polled every 50 ms; only
// complete lines are taken. Under the input lock.
// "PEEK <hex address> <hex length>" logs up to 1 KiB of guest memory; "POKE <hex address> <hex bytes>" writes bytes
// there (for example POKE 1e52b2cf8 0d000000). Only readable guest memory; a test driver's aid, like the rest of the
// live file.
static void live_memory(const char *p) {
    int poke = p[1] == 'O';
    char *end;
    uint64_t a = strtoull(p + 5, &end, 16);
    if (!poke) {
        uint64_t n = strtoull(end, NULL, 16);
        if (n > 1024) n = 1024;
        if (!a || !n || !mem_guest_readable(a, n)) {
            rt_log("peek: %#llx +%#llx not readable", (unsigned long long)a, (unsigned long long)n);
            return;
        }
        for (uint64_t i = 0; i < n; i += 32) {
            char line[100];
            int k = 0;
            for (uint64_t j = i; j < n && j < i + 32; j++)
                k += snprintf(line + k, sizeof line - k, "%02x%s", *(const uint8_t *)(uintptr_t)(a + j), (j & 3) == 3 ? " " : "");
            rt_log("peek: %#llx: %s", (unsigned long long)(a + i), line);
        }
        return;
    }
    uint8_t b[64];
    int n = 0;
    for (const char *q = end; *q && n < 64;) {
        while (*q == ' ') q++;
        unsigned v;
        if (sscanf(q, "%2x", &v) != 1) break;
        b[n++] = (uint8_t)v;
        q += 2;
    }
    if (!a || !n || !mem_guest_readable(a, (uint64_t)n)) {
        rt_log("poke: %#llx (%d bytes) not writable", (unsigned long long)a, n);
        return;
    }
    memcpy((void *)(uintptr_t)a, b, (size_t)n);
    rt_log("poke: %#llx: %d bytes written", (unsigned long long)a, n);
}

// One live line ("SHOT <path>", "[+<ticks>] <event>"), counted from tick. Under the input lock.
static void live_line(char *p, uint64_t tick) {
    char *h = strchr(p, '#');
    if (h) *h = 0;
    while (*p == ' ' || *p == '\t') p++;
    if (!strncmp(p, "SHOT ", 5)) {
        rt_shot_request(p + 5);
        return;
    }
    if (!strncmp(p, "CENSUS ", 7)) {   // TOTK_FN_CENSUS's next window (scene_start.c)
        fn_census_mark(p + 7);
        return;
    }
    if (!strncmp(p, "PEEK ", 5) || !strncmp(p, "POKE ", 5)) {   // a test driver reads or writes guest memory
        live_memory(p);
        return;
    }
    unsigned long long delay = 0;
    int k = 0;
    if (*p == '+' && sscanf(p + 1, "%llu%n", &delay, &k) == 1) p += 1 + k;
    char buf[600];
    snprintf(buf, sizeof buf, "%llu %s", (unsigned long long)(tick + delay), p);
    ScriptEv e;
    if (script_parse(buf, 0, &e) > 0 && !e.timed) script_push(&e);
}

// Lines the runtime itself sends (input_inject: auto_match.c), in TOTK_INPUT_LIVE's syntax, taken at the next poll.
static PlatMutex inject_lock = PLAT_MUTEX_INIT;
static char inject_buf[2048];
static size_t inject_len;

void input_inject(const char *line) {
    size_t n = strlen(line);
    plat_mutex_lock(&inject_lock);
    if (inject_len + n + 1 < sizeof inject_buf) {
        memcpy(inject_buf + inject_len, line, n);
        inject_len += n;
        inject_buf[inject_len++] = '\n';
    }
    plat_mutex_unlock(&inject_lock);
}

static void script_injected(void) {
    char local[sizeof inject_buf + 1];
    plat_mutex_lock(&inject_lock);
    size_t n = inject_len;
    memcpy(local, inject_buf, n);
    inject_len = 0;
    plat_mutex_unlock(&inject_lock);
    if (!n) return;
    local[n] = 0;
    uint64_t tick = frame_step_ticks();
    for (char *p = local, *e; *p; p = e + 1) {
        e = strchr(p, '\n');
        *e = 0;
        live_line(p, tick);
    }
}

static void script_live(void) {
    static int state;           // 0 not read, 1 on, -1 off
    static long offset;
    static uint64_t next_ns;
    static const char *path;
    if (state < 0) return;
    if (!state) {
        path = cfg_get("TOTK_INPUT_LIVE");
        state = path && *path ? 1 : -1;
        if (state < 0) return;
        rt_log("input: live script %s", path);
    }
    uint64_t now = kern_now_ns();
    if (now < next_ns) return;
    next_ns = now + 50000000ull;
    FILE *f = fopen(path, "rb");
    if (!f) return;
    if (fseek(f, offset, SEEK_SET)) { fclose(f); return; }
    char line[512];
    uint64_t tick = frame_step_ticks();
    while (fgets(line, sizeof line, f)) {
        size_t n = strlen(line);
        if (!n || line[n - 1] != '\n') break;   // a line still being written: read it next time
        offset += (long)n;
        line[--n] = 0;
        if (n && line[n - 1] == '\r') line[--n] = 0;
        live_line(line, tick);
    }
    fclose(f);
}

static void script_apply(uint64_t *b, int32_t sl[2], int32_t sr[2]) {
    if (!script_state) script_load();
    script_injected();
    script_live();
    if (!script_n) return;
    uint64_t fr = __atomic_load_n(&gfx_counters.frames, __ATOMIC_RELAXED), tick = frame_step_ticks();
    int64_t w = frame_step_world_us();
    for (int i = 0; i < script_n; i++) {
        ScriptEv *e = &script_ev[i];
        if (e->timed ? w < 0 : script_mixed && w >= 0) continue;
        uint64_t now = e->timed ? (uint64_t)w : tick;
        if (now < e->at || (now >= e->at + e->hold && (e->logged || !e->timed))) continue;
        if (e->stick == 3 && e->logged) continue;
        if (!e->logged) {
            e->logged = 1;
            if (e->timed) rt_log("input: script frame %llu at %.1f ms: %s", (unsigned long long)fr, w / 1000.0, e->text);
            else rt_log("input: script frame %llu tick %llu: %s", (unsigned long long)fr, (unsigned long long)tick, e->text);
        }
        if (e->stick == 3) {
            int64_t x = (int64_t)script_mouse[0] + e->x, y = (int64_t)script_mouse[1] + e->y;
            script_mouse[0] = (int32_t)(x < INT32_MIN ? INT32_MIN : x > INT32_MAX ? INT32_MAX : x);
            script_mouse[1] = (int32_t)(y < INT32_MIN ? INT32_MIN : y > INT32_MAX ? INT32_MAX : y);
        } else if (e->stick) { int32_t *s = e->stick == 1 ? sl : sr; s[0] = e->x; s[1] = e->y; }
        else *b |= 1ull << e->bit;
    }
}

// TOTK_INPUT_RECORD=<file>: writes the merged input as TOTK_INPUT_SCRIPT lines, one per button press and per stick
// segment, so a played session replays as a script. A stick segment ends when an axis moves by more than REC_STICK_STEP.
// An event that begins on the world clock is written timed ("@<ms>", hold in ms), one before it in ticks
// (frame_step_ticks). When the world clock starts, held buttons and sticks are cut there and go on as timed events.
enum { REC_STICK_STEP = 2048 };
static FILE *rec;
static int rec_state;                // 0 not opened, 1 recording, -1 off
static uint64_t rec_down[16];        // tick + 1 at which each button went down, 0 while up
static int64_t rec_down_w[16];       // the world clock then, -1 before it started
static uint64_t rec_stick_from[2];   // tick + 1 at which the current non-zero stick segment began
static int64_t rec_stick_w[2];
static int32_t rec_stick[2][2];
static int64_t rec_last_w = -1;      // the world clock at the previous apply

// "<tick> <what> <hold>" or "@<ms> <what> <hold ms>": from tick from and world clock from_w to now.
static void rec_line(uint64_t from, int64_t from_w, uint64_t fr, int64_t w, const char *what) {
    if (from_w >= 0 && w >= from_w)
        fprintf(rec, "@%.1f %s %.1f\n", from_w / 1000.0, what, (w > from_w ? w - from_w : 1000) / 1000.0);
    else
        fprintf(rec, "%llu %s %llu\n", (unsigned long long)from, what, (unsigned long long)(fr > from ? fr - from : 1));
}

static void rec_close_stick(int s, uint64_t fr, int64_t w) {
    if (!rec_stick_from[s]) return;
    char what[48];
    snprintf(what, sizeof what, "%s %d %d", s ? "RSTICK" : "LSTICK", rec_stick[s][0], rec_stick[s][1]);
    rec_line(rec_stick_from[s] - 1, rec_stick_w[s], fr, w, what);
    rec_stick_from[s] = 0;
}

static void rec_flush_all(void) {
    if (rec_state != 1) return;
    uint64_t fr = frame_step_ticks() + 1;
    int64_t w = frame_step_world_us();
    for (int i = 0; i < 16; i++)
        if (rec_down[i]) { rec_line(rec_down[i] - 1, rec_down_w[i], fr, w, script_buttons[i].name); rec_down[i] = 0; }
    rec_close_stick(0, fr, w);
    rec_close_stick(1, fr, w);
    fflush(rec);
}

static void rec_apply(uint64_t b, const int32_t sl[2], const int32_t sr[2]) {
    if (!rec_state) {
        const char *path = cfg_get("TOTK_INPUT_RECORD");   // no default: not recording when unset
        rec = path && *path ? fopen(path, "w") : NULL;
        rec_state = rec ? 1 : -1;
        if (path && *path && !rec) rt_log("input: cannot open TOTK_INPUT_RECORD %s", path);
        if (rec) { fprintf(rec, "# Recorded input (TOTK_INPUT_RECORD); frame = 60 Hz ticks of game time, @ms = world clock.\n"); atexit(rec_flush_all);
                   rt_log("input: recording to %s", path); }
    }
    if (rec_state != 1) return;
    uint64_t fr = frame_step_ticks();
    int64_t w = frame_step_world_us();
    int wrote = 0;
    if (w >= 0 && rec_last_w < 0) {   // the world clock starts: what is held goes on as timed events from @0
        for (int i = 0; i < 16; i++)
            if (rec_down[i]) {
                rec_line(rec_down[i] - 1, -1, fr, -1, script_buttons[i].name);
                rec_down[i] = fr + 1, rec_down_w[i] = w;
                wrote = 1;
            }
        for (int s = 0; s < 2; s++)
            if (rec_stick_from[s]) {
                rec_close_stick(s, fr, -1);
                rec_stick_from[s] = fr + 1, rec_stick_w[s] = w;
                wrote = 1;
            }
    }
    rec_last_w = w;
    for (int i = 0; i < 16; i++) {
        int bit = script_buttons[i].bit, down = (b >> bit & 1) != 0;
        if (down && !rec_down[i]) rec_down[i] = fr + 1, rec_down_w[i] = w;
        else if (!down && rec_down[i]) {
            rec_line(rec_down[i] - 1, rec_down_w[i], fr, w, script_buttons[i].name);
            rec_down[i] = 0;
            wrote = 1;
        }
    }
    const int32_t *st[2] = {sl, sr};
    for (int s = 0; s < 2; s++) {
        int moved = abs(st[s][0] - rec_stick[s][0]) > REC_STICK_STEP || abs(st[s][1] - rec_stick[s][1]) > REC_STICK_STEP ||
                    ((st[s][0] || st[s][1]) != (rec_stick[s][0] || rec_stick[s][1]));
        if (!moved) continue;
        if (rec_stick_from[s]) { rec_close_stick(s, fr, w); wrote = 1; }
        rec_stick[s][0] = st[s][0]; rec_stick[s][1] = st[s][1];
        if (st[s][0] || st[s][1]) rec_stick_from[s] = fr + 1, rec_stick_w[s] = w;
    }
    if (wrote) fflush(rec);
}

void input_direct_mouse_sample(int enabled, int32_t *dx, int32_t *dy) {
    plat_mutex_lock(&lock);
    enabled = enabled && !g_block && !g_menu;
    *dx = script_mouse[0]; *dy = script_mouse[1];
    script_mouse[0] = script_mouse[1] = 0;
    if (!enabled) { *dx = *dy = 0; }
    else if (ikb_captured() && ikb_foreground() && input_cursor_allowed()) {
        int32_t x, y;
        ikb_mouse_take(&x, &y);
        int64_t sx = (int64_t)*dx + x, sy = (int64_t)*dy + y;
        *dx = (int32_t)(sx < INT32_MIN ? INT32_MIN : sx > INT32_MAX ? INT32_MAX : sx);
        *dy = (int32_t)(sy < INT32_MIN ? INT32_MIN : sy > INT32_MAX ? INT32_MAX : sy);
    }
    if (enabled && (*dx || *dy) && rec_state == 1) {
        char what[80];
        snprintf(what, sizeof what, "MOUSE %d %d", *dx, *dy);
        int64_t w = frame_step_world_us();
        uint64_t tick = frame_step_ticks();
        rec_line(tick, w, tick + 1, w, what);
        fflush(rec);
    }
    plat_mutex_unlock(&lock);
}

static float mouse_sens = -1;              // TOTK_MOUSE_SENS, 0 = mouse camera off; live (cfg_version)
static unsigned mouse_sens_seen;

static float mouse_sens_get(void) {
    unsigned ver = cfg_version();
    if (mouse_sens >= 0 && ver == mouse_sens_seen) return mouse_sens;
    mouse_sens_seen = ver;
    double v = cfg_double("TOTK_MOUSE_SENS");
    mouse_sens = (float)(v < 0 ? 0 : v > 10 ? 10 : v);
    return mouse_sens;
}


// ---- walk key: the keyboard's stick samples scaled down while a key is held (TOTK_WALK_KEY, TOTK_WALK_SCALE)
// A keyboard key is all or nothing, so every keyboard-driven stick sample is +/-32767 and the game only ever sees a
// full tilt. Holding this key scales those two samples, which gives the half tilt a gamepad gets from its analog range,
// so the keyboard can walk as well as run. yuzu and eden do the same with their modifier and modifier_scale settings.
// Only the keyboard is scaled: the gamepad's axes and the mouse camera sample their own values.
static int walk_key = KEY_NONE;        // TOTK_WALK_KEY as a KEY_*, KEY_NONE = off; live (cfg_version)
static float walk_scale = 0.51f;       // TOTK_WALK_SCALE, 0.2 to 0.9; live (cfg_version)
static unsigned walk_seen = ~0u;

// The ini takes the key names the Controls tab writes; a hand-written line may spell them in any case.
static int name_matches(const char *name, const char *key) {
    for (; *name && *key; name++, key++) {
        unsigned char a = (unsigned char)*name, b = (unsigned char)*key;
        if (a >= 'A' && a <= 'Z') a = (unsigned char)(a - 'A' + 'a');
        if (b >= 'A' && b <= 'Z') b = (unsigned char)(b - 'A' + 'a');
        if (a != b) return 0;
    }
    return *name == *key;
}

static void walk_get(void) {
    unsigned ver = cfg_version();
    if (ver == walk_seen) return;
    walk_seen = ver;
    const char *name = cfg_value("TOTK_WALK_KEY");   // "none" (the default) turns the key off
    int key = KEY_NONE;
    if (*name && !name_matches(name, "none")) {
        for (int k = KEY_A; k < KEY_COUNT && key == KEY_NONE; k++)
            if (input_key_name(k) && name_matches(name, input_key_name(k))) key = k;
        if (key == KEY_NONE) rt_log("input: walk_key: unknown key '%s', the keyboard sticks keep their full tilt", name);
    }
    // 0.51 rather than 0.5: a keyboard sample is 32767, and 32767 * 0.5 = 16383 falls one short of stick_bits'
    // STICK_DIR (16384), which would leave the game's stick-direction bits clear while the walk key is held. The value
    // in the settings table carries that default; this code only rejects what the table's range does not allow.
    const char *sv = cfg_value("TOTK_WALK_SCALE");
    char *end;
    double d = strtod(sv, &end);
    double s = end == sv || *end || !(d >= 0.2 && d <= 0.9) ? strtod(cfg_meta("TOTK_WALK_SCALE")->def, NULL) : d;
    if (key != walk_key || (float)s != walk_scale) {
        walk_key = key;
        walk_scale = (float)s;
        rt_log("input: walk key %s, keyboard sticks at %.0f%% of their tilt (mouse and gamepad unchanged)",
               key != KEY_NONE ? input_key_name(key) : "off", s * 100);
    }
}

static int mouse_selector;
int input_direct_mouse_selector_active(void) { return __atomic_load_n(&mouse_selector, __ATOMIC_RELAXED) != 0; }

// Selector 1 is a radial wheel, 2..4 are distinct horizontal quick lists; only a wheel retains a virtual cursor.
// Under `lock`.
static void mouse_camera(int32_t out[2], int selector) {
    static uint64_t frame = ~0ull, t0;
    static int32_t held[2];
    static int was_selector;
    static float cursor[2];
    static InputMouseRow row;
    uint64_t now = plat_now_ns();
    int32_t dx, dy;
    if (input_mouse_gyro_on()) {   // the six-axis sensor takes the mouse (mouse_gyro_tick); the right stick gets none of it
        out[0] = out[1] = 0;
        return;
    }
    if (!input_direct_mouse_enabled() || !ikb_captured()) selector = 0;
    __atomic_store_n(&mouse_selector, selector, __ATOMIC_RELAXED);
    if (selector) {
        if (was_selector != selector) cursor[0] = cursor[1] = 0, row = (InputMouseRow){0};
        was_selector = selector;
        ikb_mouse_take(&dx, &dy);
        if (selector == 1) input_direct_mouse_radial(dx, dy, mouse_sens_get(), cursor, out);
        else input_direct_mouse_row(dx, mouse_sens_get(), now, &row, out);
        held[0] = held[1] = 0; frame = ~0ull;
        return;
    }
    if (was_selector) {
        was_selector = 0; cursor[0] = cursor[1] = 0; row = (InputMouseRow){0};
        ikb_mouse_take(&dx, &dy);   // release the wheel without sending its last movement to the camera
        held[0] = held[1] = out[0] = out[1] = 0; frame = ~0ull;
        return;
    }
    if (input_direct_mouse_active()) {
        held[0] = held[1] = out[0] = out[1] = 0;
        frame = ~0ull;
        return;   // the camera update takes the raw counts itself, once, outside the HID stick path
    }
    if (!ikb_captured()) {
        ikb_mouse_take(&dx, &dy);
        held[0] = held[1] = 0;
        frame = ~0ull;
    } else {
        uint64_t fr = __atomic_load_n(&gfx_counters.frames, __ATOMIC_RELAXED);
        double age = frame == ~0ull ? 0 : (double)(now - t0) / 1e9;
        if (fr != frame) {
            double dt = age < 0.004 ? 0.004 : age > 0.1 ? 0.1 : age;
            ikb_mouse_take(&dx, &dy);
            input_mouse_stick(dx, dy, dt, mouse_sens_get(), held);
            frame = fr;
            t0 = now;
        } else if (age > 0.1) {
            held[0] = held[1] = 0;   // frames stopped: do not hold a deflection
        }
    }
    double k = cam_speed_applied(), x = held[0] / k, y = held[1] / k, len = sqrt(x * x + y * y);
    if (len > STICK_MAX) x *= STICK_MAX / len, y *= STICK_MAX / len;
    out[0] = (int32_t)lround(x);
    out[1] = (int32_t)lround(y);
}

static float stick_dead[2] = {-1, -1};     // input_pad_deadzone of the left and right stick; live (cfg_version)
static unsigned stick_dead_seen;

static float stick_dead_get(int s) {
    unsigned ver = cfg_version();
    if (stick_dead[0] < 0 || ver != stick_dead_seen) {
        stick_dead_seen = ver;
        stick_dead[0] = input_pad_deadzone(0);
        stick_dead[1] = input_pad_deadzone(1);
    }
    return stick_dead[s];
}

// One gamepad stick through the dead zone; SDL's Y grows downwards, the Switch's upwards.
static void stick(SDL_GamepadAxis ax, SDL_GamepadAxis ay, float dead, int32_t out[2]) {
    input_pad_stick(SDL_GetGamepadAxis(pad, ax), -(int32_t)SDL_GetGamepadAxis(pad, ay), dead, out);
}

// Open the first gamepad when none is open or the open one went away; logs once per change.
static void scan_pads(void) {
    if (pad && SDL_GamepadConnected(pad)) return;
    if (pad) {
        SDL_CloseGamepad(pad); pad = NULL; sensor_pad = 0; sensor_ok = 0;
        plat_xchg32(&pad_layout_shown, -1);
        for (int i = 0; i < 4; i++) plat_xchg32(&pad_labels[i], PAD_LABEL_NONE);
        rt_log("input: gamepad disconnected");
    }
    int n = 0;
    SDL_JoystickID *ids = SDL_GetGamepads(&n);
    for (int i = 0; ids && i < n && !pad; i++) pad = SDL_OpenGamepad(ids[i]);
    SDL_free(ids);
    if (!pad) return;
    pad_rumble = SDL_GetBooleanProperty(SDL_GetGamepadProperties(pad), SDL_PROP_GAMEPAD_CAP_RUMBLE_BOOLEAN, false);
    pad_east_a = SDL_GetGamepadButtonLabel(pad, SDL_GAMEPAD_BUTTON_EAST) == SDL_GAMEPAD_BUTTON_LABEL_A;
    for (int i = 0; i < 4; i++) {
        SDL_GamepadButtonLabel lb = SDL_GetGamepadButtonLabel(pad, pad_sdl[PAD_SOUTH + i]);
        plat_xchg32(&pad_labels[i], lb == SDL_GAMEPAD_BUTTON_LABEL_A          ? PAD_LABEL_A
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_B        ? PAD_LABEL_B
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_X        ? PAD_LABEL_X
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_Y        ? PAD_LABEL_Y
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_CROSS    ? PAD_LABEL_CROSS
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_CIRCLE   ? PAD_LABEL_CIRCLE
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_SQUARE   ? PAD_LABEL_SQUARE
                                            : lb == SDL_GAMEPAD_BUTTON_LABEL_TRIANGLE ? PAD_LABEL_TRIANGLE
                                                                                      : PAD_LABEL_NONE);
    }
    pad_layout = -1;
    int motion = SDL_GamepadHasSensor(pad, SDL_SENSOR_GYRO) && SDL_GamepadHasSensor(pad, SDL_SENSOR_ACCEL);
    rt_log("input: gamepad \"%s\" (%s, %s, east button %s)", SDL_GetGamepadName(pad), pad_rumble ? "rumble" : "no rumble",
           motion ? "gyro and accelerometer" : "no motion sensors", pad_east_a ? "labelled A" : "not labelled A");
}

// Under lock: the layout of the open gamepad, picked again when a setting or the gamepad changed; logs each change.
static int pad_layout_get(void) {
    unsigned ver = cfg_version();
    if (pad_layout >= 0 && ver == pad_layout_seen) return pad_layout;
    pad_layout_seen = ver;
    int was = pad_layout;
    const char *set = cfg_value("TOTK_PAD_LAYOUT");
    pad_layout = input_pad_layout_pick(set, pad_east_a);
    if (pad_layout != was)
        rt_log("input: gamepad layout %s (pad_layout = %s)", pad_layout == PAD_LAYOUT_XBOX ? "xbox" : "nintendo", set);
    plat_xchg32(&pad_layout_shown, pad_layout);
    return pad_layout;
}

// The TOTK_BIND_* values last applied, one per line; the tables are built again when one changes (the menu's remapping rows write
// them while the game runs). Under lock.
static unsigned binds_seen = ~0u;
static char binds_applied[4096];

static void binds_refresh(void) {
    unsigned v = cfg_version();
    if (v == binds_seen) return;
    binds_seen = v;
    char now[sizeof binds_applied];
    size_t len = 0;
    for (int a = 0; a < ACTION_COUNT; a++) {
        char var[32];
        snprintf(var, sizeof var, "TOTK_BIND_%s", input_action_name(a));
        const char *s = cfg_get(var);
        len += (size_t)snprintf(now + len, len < sizeof now ? sizeof now - len : 0, "%s\n", s ? s : "");
    }
    if (!strcmp(now, binds_applied)) return;
    memcpy(binds_applied, now, sizeof now);
    input_map_configure();
}

// TOTK_TEST_PAD=<lx>,<ly>,<rx>,<ry> (test runs): an SDL virtual gamepad whose sticks rest at these raw SDL axis values
// (-32768..32767, down is +y), attached before the first scan so it is the gamepad the game reads: drift and full
// deflection go through the same mapping and dead zone as a real pad.
static void test_pad_attach(void) {
    static SDL_Joystick *joy;   // kept open: a virtual joystick's axes are set through an open handle
    const char *e = cfg_get("TOTK_TEST_PAD");
    int v[4];
    if (!e || !*e) return;
    if (sscanf(e, "%d,%d,%d,%d", &v[0], &v[1], &v[2], &v[3]) != 4) {
        rt_log("input: TOTK_TEST_PAD=%s is not <lx>,<ly>,<rx>,<ry>; no test gamepad", e);
        return;
    }
    SDL_VirtualJoystickDesc d;
    SDL_INIT_INTERFACE(&d);
    d.type = SDL_JOYSTICK_TYPE_GAMEPAD;
    d.naxes = SDL_GAMEPAD_AXIS_COUNT;
    d.nbuttons = SDL_GAMEPAD_BUTTON_COUNT;
    d.name = "TotK test gamepad";
    SDL_JoystickID id = SDL_AttachVirtualJoystick(&d);
    joy = id ? SDL_OpenJoystick(id) : NULL;
    if (!joy) {
        rt_log("input: test gamepad not attached (%s)", SDL_GetError());
        return;
    }
    static const SDL_GamepadAxis axes[4] = {SDL_GAMEPAD_AXIS_LEFTX, SDL_GAMEPAD_AXIS_LEFTY, SDL_GAMEPAD_AXIS_RIGHTX,
                                            SDL_GAMEPAD_AXIS_RIGHTY};
    for (int i = 0; i < 4; i++)
        SDL_SetJoystickVirtualAxis(joy, axes[i], (Sint16)(v[i] < -32768 ? -32768 : v[i] > 32767 ? 32767 : v[i]));
    rt_log("input: test gamepad attached, sticks at %d,%d %d,%d", v[0], v[1], v[2], v[3]);
}

static void start(void) {
    binds_refresh();
    const char *e = cfg_get("TOTK_INPUT");
    if (e && !strcmp(e, "none")) { state = -1; rt_log("input: disabled (TOTK_INPUT=none)"); return; }
    if (!SDL_Init(SDL_INIT_GAMEPAD)) { state = -1; rt_log("input: SDL gamepad init failed (%s), keyboard only", SDL_GetError()); }
    else state = 1;
    if (state == 1) test_pad_attach();
    if (state == 1) {
        scan_pads();
        if (!pad) rt_log("input: no gamepad (keyboard only until one is connected)");
    }
    if (state == -1) state = 2;   // keyboard only
}

static void stick_bits(uint64_t *b, int32_t x, int32_t y, int first) {
    if (x < -STICK_DIR) *b |= 1ull << (first + 0);
    if (y > STICK_DIR) *b |= 1ull << (first + 1);
    if (x > STICK_DIR) *b |= 1ull << (first + 2);
    if (y < -STICK_DIR) *b |= 1ull << (first + 3);
}

static void pick(int32_t *x, int32_t *y, int32_t kx, int32_t ky) {
    int64_t a = (int64_t)*x * *x + (int64_t)*y * *y, b = (int64_t)kx * kx + (int64_t)ky * ky;
    if (b > a) { *x = kx; *y = ky; }
}

// The shake key (B_SHAKE): the game detaches a part fused to what Ultrahand holds when the right stick swings left and
// right a few times. A press swings it for SHAKE_NS, holding keeps it swinging; each side lasts SHAKE_SIDE_NS, two
// frames at the game's 30 fps, so every side is read even at 20 fps. Returns the stick x, 0 while not shaking.
// Under lock.
#define SHAKE_NS 800000000ull
#define SHAKE_SIDE_NS 66666667ull
static int32_t shake_stick(int held) {
    static int was;
    static uint64_t from, until;
    uint64_t now = plat_now_ns();
    if (held && !was && now >= until) from = now;
    if (held && !was) until = now + SHAKE_NS;
    if (held && until < now) until = now;
    was = held;
    if (now >= until && !held) return 0;
    return (now - from) / SHAKE_SIDE_NS % 2 ? STICK_MAX : -STICK_MAX;
}

// The scroll wheel on the Purah Pad's map, which zooms with the right stick's y (up: in): each notch is a full-tilt
// pulse of MAP_ZOOM_PULSE_NS on that stick with MAP_ZOOM_GAP_NS of neutral after it, so a step of the zoom and a
// held zoom both see one notch as one push. A fast scroll's notches wait their turn (at most MAP_ZOOM_QUEUE), a turn the
// other way drops them. Returns the stick y for this poll, 0 between pulses and off the map. Under lock.
#define MAP_ZOOM_PULSE_NS 100000000ull
#define MAP_ZOOM_GAP_NS 50000000ull
#define MAP_ZOOM_QUEUE 4
static int32_t map_zoom_stick(int32_t notches, int on_map) {
    static int32_t queued, dir;
    static uint64_t until;   // the end of the pulse (dir != 0) or of the neutral after it
    uint64_t now = plat_now_ns();
    if (!on_map) { queued = dir = 0, until = 0; return 0; }
    if (notches) {
        if (queued && (notches > 0) != (queued > 0)) queued = 0;
        queued += notches;
        queued = queued > MAP_ZOOM_QUEUE ? MAP_ZOOM_QUEUE : queued < -MAP_ZOOM_QUEUE ? -MAP_ZOOM_QUEUE : queued;
    }
    if (dir) {
        if (now < until) return dir * STICK_MAX;
        dir = 0, until = now + MAP_ZOOM_GAP_NS;
        return 0;
    }
    if (now < until || !queued) return 0;
    dir = queued > 0 ? 1 : -1;
    queued -= dir;
    until = now + MAP_ZOOM_PULSE_NS;
    return dir * STICK_MAX;
}

// Under lock, state 1: the open gamepad's inputs by position (pd[PAD_*] != 0 held); 0 without a connected gamepad.
static int pad_physical(uint8_t pd[PAD_COUNT]) {
    if ((!pad || !SDL_GamepadConnected(pad)) && plat_now_ns() / 1000000u >= next_scan) { next_scan = plat_now_ns() / 1000000u + RESCAN_MS; scan_pads(); }
    SDL_UpdateGamepads();
    if (!pad || !SDL_GamepadConnected(pad)) return 0;
    for (int p = PAD_SOUTH; p < PAD_ZL; p++) pd[p] = SDL_GetGamepadButton(pad, pad_sdl[p]);
    pd[PAD_ZL] = SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_LEFT_TRIGGER) > TRIGGER_ON;
    pd[PAD_ZR] = SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_RIGHT_TRIGGER) > TRIGGER_ON;
    for (int p = PAD_ZR + 1; p < PAD_COUNT; p++) pd[p] = SDL_GetGamepadButton(pad, pad_sdl[p]);   // false without paddles
    return 1;
}

// Under lock, state 1: the open gamepad's buttons (Switch bits after TOTK_PAD_LAYOUT and the TOTK_BIND_* lines) and
// sticks; 0 without a connected gamepad.
static int pad_read(uint64_t *b, int32_t sl[2], int32_t sr[2]) {
    uint8_t pd[PAD_COUNT] = {0};
    if (!pad_physical(pd)) return 0;
    *b |= input_map_pad_buttons(pd, pad_layout_get());
    stick(SDL_GAMEPAD_AXIS_LEFTX, SDL_GAMEPAD_AXIS_LEFTY, stick_dead_get(0), sl);
    stick(SDL_GAMEPAD_AXIS_RIGHTX, SDL_GAMEPAD_AXIS_RIGHTY, stick_dead_get(1), sr);
    return 1;
}

int input_pad_stick_percent(double pct[2]) {
    int ok = 0;
    pct[0] = pct[1] = 0;
    plat_mutex_lock(&lock);
    if (state == 1 && pad && SDL_GamepadConnected(pad)) {   // the game's poll keeps the state fresh (SDL_UpdateGamepads)
        pct[0] = input_stick_percent(SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_LEFTX),
                                     SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_LEFTY));
        pct[1] = input_stick_percent(SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_RIGHTX),
                                     SDL_GetGamepadAxis(pad, SDL_GAMEPAD_AXIS_RIGHTY));
        ok = 1;
    }
    plat_mutex_unlock(&lock);
    return ok;
}

static uint64_t g_buttons_last;   // the merged buttons of the last poll (input_buttons_last)
static volatile int32_t g_human_off;   // input_human(0): the gamepad, keys and mouse are not read

static uint64_t g_human_ms;            // plat_now_ms of the last poll with the player's own input (input_human_last_ms)

void input_human(int on) { plat_xchg32(&g_human_off, !on); }
uint64_t input_human_last_ms(void) { return __atomic_load_n(&g_human_ms, __ATOMIC_RELAXED); }

static void poll_merged(uint64_t *buttons, int32_t *lx, int32_t *ly, int32_t *rx, int32_t *ry) {
    uint64_t b = 0;
    int32_t sl[2] = {0, 0}, sr[2] = {0, 0};
    plat_mutex_lock(&lock);
    if (!state) start();
    if (state > 0 && g_human_off) {   // the pad is still read (its events drained), and its state dropped
        binds_refresh();
        if (state == 1) pad_read(&b, sl, sr);
        b = 0, sl[0] = sl[1] = sr[0] = sr[1] = 0;
    } else if (state > 0) {
        binds_refresh();
        if (state == 1) pad_read(&b, sl, sr);
        int pad_used = b || abs(sl[0]) > PAD_USED || abs(sl[1]) > PAD_USED || abs(sr[0]) > PAD_USED ||
                       abs(sr[1]) > PAD_USED, kbm_used = 0;
        if (ikb_foreground()) {
            uint8_t down[KEY_COUNT] = {0};
            // Mouse buttons count only while the cursor is captured, and a button already held when the capture began
            // (the click that refocused the window) is ignored until it is released. While a game menu has the pointer
            // (menu_cursor.c) and it is over the window, the left and right buttons are that menu's A and B, and the
            // middle and side buttons keep their bindings: bound to L and R they turn the menu's tabs.
            static int was_captured;
            static uint8_t mouse_ignore[KEY_COUNT];
            int cap = ikb_captured();
            float pointer_x, pointer_y;
            int menu_pointer = !cap && menu_cursor_pointer() && ikb_pointer(&pointer_x, &pointer_y);
            for (int k = 1; k < KEY_COUNT; k++) {
                down[k] = ikb_down(k);
                kbm_used |= down[k];
                if (k < KEY_MOUSE_L || k > KEY_MOUSE_X2) continue;
                if (cap && !was_captured) mouse_ignore[k] = down[k];
                if (!down[k]) mouse_ignore[k] = 0;
                int counts = cap || (menu_pointer && k != KEY_MOUSE_L && k != KEY_MOUSE_R);
                if (!counts || mouse_ignore[k]) down[k] = 0;
            }
            was_captured = cap;
            b |= input_map_buttons(down);
            int32_t k[2];
            walk_get();
            int walk = walk_key != KEY_NONE && down[walk_key];
            input_map_stick(down, 0, k);
            if (walk) k[0] = (int32_t)(k[0] * walk_scale), k[1] = (int32_t)(k[1] * walk_scale);
            pick(&sl[0], &sl[1], k[0], k[1]);
            input_map_stick(down, 1, k);
            if (walk) k[0] = (int32_t)(k[0] * walk_scale), k[1] = (int32_t)(k[1] * walk_scale);
            pick(&sr[0], &sr[1], k[0], k[1]);
            int selector = b & (1ull << B_L) ? 1 : b & (1ull << B_UP) ? 2 :
                           b & (1ull << B_LEFT) ? 3 : b & (1ull << B_RIGHT) ? 4 : 0;
            // Only while the wheel or a strip is on screen (menu_cursor.c reads the focused screen): L also soothes the
            // horse and turns menu tabs, the D-pad does other things too, and then the mouse stays on the camera.
            // Before the screens were read (the menu cursor off) the buttons alone decide, as before.
            if (selector && menu_cursor_shortcut() == 0) selector = 0;
            mouse_camera(k, selector);
            // On the map the left stick moves the cursor and the right one zooms: the mouse moves the cursor there,
            // the scroll wheel zooms (map_zoom_stick). Elsewhere the wheel is unbound; its notches are dropped.
            int map = menu_cursor_map();
            if (map) pick(&sl[0], &sl[1], k[0], k[1]);
            else pick(&sr[0], &sr[1], k[0], k[1]);
            int32_t zoom = map_zoom_stick(ikb_wheel_take(), map);
            if (zoom) pick(&sr[0], &sr[1], 0, zoom);
            int32_t shake = shake_stick(input_map_held(down, B_SHAKE));
            if (shake) sr[0] = shake, sr[1] = 0;
            // A mouse shake (mouse_direct.c) moves the stick with the mouse, side by side, and lets go when it rests
            else if (input_direct_mouse_shake()) sr[0] = input_direct_mouse_shake() * STICK_MAX, sr[1] = 0;
            static uint32_t travel_seen;
            uint32_t travel = ikb_mouse_travel();
            if (travel - travel_seen >= MOUSE_USED) kbm_used = 1;
            travel_seen = travel;
        }
        if (pad_used || kbm_used) __atomic_store_n(&g_human_ms, plat_now_ms(), __ATOMIC_RELAXED);
        // A press or a full-way stick on the pad wins over keys held in the same poll: the player picked it up
        if (pad_used) __atomic_store_n(&g_kbm_last, 0, __ATOMIC_RELAXED);
        else if (kbm_used) __atomic_store_n(&g_kbm_last, 1, __ATOMIC_RELAXED);
    }
    script_apply(&b, sl, sr);
    rec_apply(b, sl, sr);
    // Minus and Plus held together (gamepad or keys) open or close the menu and never reach the game
    static int combo_held;
    int32_t st[4] = {sl[0], sl[1], sr[0], sr[1]};
    int toggle = input_menu_gate(&combo_held, menu_is_open(), &b, st);
    static int overlay_held;   // L3+R3 step the performance overlay (F10)
    int overlay = input_overlay_gate(&overlay_held, &b);
    sl[0] = st[0], sl[1] = st[1], sr[0] = st[2], sr[1] = st[3];
    plat_mutex_unlock(&lock);
    if (toggle) menu_toggle();
    if (overlay) menu_perf_cycle();
    stick_bits(&b, sl[0], sl[1], B_SL_LEFT);
    stick_bits(&b, sr[0], sr[1], B_SR_LEFT);
    // Y recentres the game's camera; the virtual controller does not level with it: the game moves its camera by the
    // controller's tilt since the last state it took before the recentre, so a controller levelled then turned the
    // camera by that much at the next move (measured: 41.7 degrees for 10 degrees of mouse after Y with the controller
    // 10 degrees down). The recentre key (mouse_gyro_recenter_key) still levels it.
    static uint64_t prev_buttons;
    if (b & ~prev_buttons & (1ull << B_Y) && mgb_level_on_y(0)) __atomic_store_n(&mg_recenter_req, 1, __ATOMIC_RELAXED);
    prev_buttons = b;
    __atomic_store_n(&g_buttons_last, b, __ATOMIC_RELAXED);
    *buttons = b; *lx = sl[0]; *ly = sl[1]; *rx = sr[0]; *ry = sr[1];
}

uint64_t input_buttons_last(void) { return __atomic_load_n(&g_buttons_last, __ATOMIC_RELAXED); }

// Text entry (swkbd_*.c): while it is open the game reads no input, as behind the keyboard applet; after it closes
// the game reads none until every button and stick direction is released, so the press that closed it stays there.
// g_block: 0 off, 1 text entry open, 2 closed, waiting for the release. The cursor is released while it is open.
// When g_block and g_menu last went to 2 (plat_now_ns). The wait for the release ends after RELEASE_WAIT_NS even with
// something held: an input that never reads as released (a button another program holds down, a key whose release
// went to another window, a stick that rests outside its dead zone) would otherwise keep the game deaf until restart
// (upstream issues #462, #494). A press that closed the menu is let go well within the wait; one still held after it is meant.
static volatile uint64_t g_block_closed, g_menu_closed;
#define RELEASE_WAIT_NS 1000000000ull

int input_cursor_allowed(void) {
    const char *in = cfg_get("TOTK_INPUT");
    return g_block != 1 && g_menu != 1 && mouse_sens_get() > 0 && !(in && !strcmp(in, "none")) && !menu_cursor_pointer();
}

void input_block(int on) {
    if (!on) __atomic_store_n(&g_block_closed, plat_now_ns(), __ATOMIC_RELEASE);
    plat_xchg32(&g_block, on ? 1 : 2);
    ikb_cursor_update();
}

// The in-game menu (ui/menu.cpp) blocks the game's input the same way: g_menu 0 closed, 1 open, 2 closed, waiting for
// the release. The cursor is released while it is open, for the menu's mouse.
void input_menu(int open) {
    if (!open) __atomic_store_n(&g_menu_closed, plat_now_ns(), __ATOMIC_RELEASE);
    plat_xchg32(&g_menu, open ? 1 : 2);
    if (!open) ikb_menu_closed();   // the capture before Esc comes back
    ikb_cursor_update();
}

// 1 while flag (g_block, g_menu) blocks the game's input; state 2 ends at the first poll with nothing held, or with
// something still held RELEASE_WAIT_NS after closed. A stick axis counts as held as well: with the walk key the
// keyboard's sticks move part way without setting a direction bit, so a gate that watched the buttons alone would let
// that movement through the moment the menu or the text entry closes.
static int blocked(volatile int32_t *flag, volatile uint64_t *closed, const char *what, uint64_t buttons,
                   const int32_t *axes) {
    int32_t k = *flag;
    if (k != 2) return k != 0;
    int held = buttons != 0;
    for (int i = 0; i < 4; i++) held |= axes[i] != 0;
    if (held && plat_now_ns() - __atomic_load_n(closed, __ATOMIC_ACQUIRE) < RELEASE_WAIT_NS) return 1;
    if (plat_cas32(flag, 0, 2) != 2) return *flag != 0;   // reopened meanwhile
    if (held)
        rt_log("input: the %s closed 1 s ago and input is still held (buttons %#llx, sticks %d %d %d %d); the game "
               "gets it from now on", what, (unsigned long long)buttons, axes[0], axes[1], axes[2], axes[3]);
    return 0;
}

void input_poll(uint64_t *buttons, int32_t *lx, int32_t *ly, int32_t *rx, int32_t *ry) {
    poll_merged(buttons, lx, ly, rx, ry);
    if (!g_block && !g_menu) menu_cursor_poll(buttons);
    const int32_t axes[4] = {*lx, *ly, *rx, *ry};
    int text = blocked(&g_block, &g_block_closed, "text entry", *buttons, axes),
        menu = blocked(&g_menu, &g_menu_closed, "menu", *buttons, axes);
    if (!text && !menu) return;
    *buttons = 0; *lx = *ly = *rx = *ry = 0;
}

void input_poll_ui(uint64_t *buttons, int32_t *lx, int32_t *ly, int32_t *rx, int32_t *ry) {
    poll_merged(buttons, lx, ly, rx, ry);
}

int input_pad_read(uint64_t *buttons, int32_t *lx, int32_t *ly) {
    uint64_t b = 0;
    int32_t sl[2] = {0, 0}, sr[2] = {0, 0};
    plat_mutex_lock(&lock);
    if (!state) start();
    if (state > 0) binds_refresh();
    int ok = state == 1 && pad_read(&b, sl, sr);
    plat_mutex_unlock(&lock);
    *buttons = b;
    *lx = sl[0];
    *ly = sl[1];
    return ok;
}

uint16_t rumble_motor(float a, float curve, float strength) {
    if (!(a > 0) || !(strength > 0)) return 0;
    float v = powf(a > 1 ? 1 : a, curve) * strength * 65535.0f + 0.5f;
    return v >= 65535.0f ? 65535 : (uint16_t)v;
}

int input_pad_layout(void) {
    return (int)plat_cas32(&pad_layout_shown, 0, 0);
}

int input_pad_label(int pad_id) {
    if (pad_id < PAD_SOUTH || pad_id > PAD_NORTH) return PAD_LABEL_NONE;
    return (int)plat_cas32(&pad_labels[pad_id - PAD_SOUTH], 0, 0);
}

void input_map_snapshot(InputMap *m) {
    plat_mutex_lock(&lock);
    if (!state) start();
    if (state > 0) binds_refresh();
    *m = input_map;
    plat_mutex_unlock(&lock);
}

int input_capture(int reset, int *id) {
    static uint8_t prev_k[KEY_COUNT], prev_p[PAD_COUNT];
    static int prev_esc;
    uint8_t k[KEY_COUNT] = {0}, p[PAD_COUNT] = {0};
    int fg = ikb_foreground();
    for (int i = 1; i < KEY_COUNT; i++) k[i] = fg && ikb_down(i);
    int esc = fg && ikb_escape();
    plat_mutex_lock(&lock);
    if (!state) start();
    if (state == 1) pad_physical(p);
    plat_mutex_unlock(&lock);
    int got = INPUT_CAPTURE_NONE;
    if (!reset) {
        if (esc && !prev_esc) got = INPUT_CAPTURE_CANCEL;
        for (int i = 1; i < KEY_COUNT && !got; i++)
            if (k[i] && !prev_k[i]) got = INPUT_CAPTURE_KEY, *id = i;
        for (int i = 1; i < PAD_COUNT && !got; i++)
            if (p[i] && !prev_p[i]) got = INPUT_CAPTURE_PAD, *id = i;
    }
    memcpy(prev_k, k, sizeof k);
    memcpy(prev_p, p, sizeof p);
    prev_esc = esc;
    return got;
}

int input_rumble_triggers_enabled(void) {
    return cfg_bool("TOTK_RUMBLE_TRIGGERS");
}

int input_rumble(uint16_t low, uint16_t high, uint32_t ms) {
    int ok = 0;
    static int triggers = -1;
    static unsigned seen;
    if (triggers < 0 || seen != cfg_version()) seen = cfg_version(), triggers = input_rumble_triggers_enabled();
    plat_mutex_lock(&lock);
    if (state == 1 && pad && pad_rumble) {
        ok = SDL_RumbleGamepad(pad, low, high, ms);
        if (triggers) SDL_RumbleGamepadTriggers(pad, high, high, ms);   // unsupported pads return false: ignored
    }
    plat_mutex_unlock(&lock);
    return ok;
}

// SDL gamepad sensor axes (SDL_sensor.h, a gamepad held in front of you): x to the right, y up out of the face (lying
// flat face up, +y points at the ceiling), z toward the player (out of the bottom edge). The accelerometer reads the
// push against gravity in m/s^2 (lying flat: y = +9.81); the gyro reads rad/s, counter-clockwise positive (right hand).
// Switch six-axis axes (nn::hid, as MacNativeGames' GCMotion feed and its Pro Controller HID path use them): x to the
// right, y toward the top edge (away from the player), z out of the face; acceleration as gravity reads (lying flat:
// z = -1 G). So Switch x = SDL x, Switch y = -SDL z, Switch z = SDL y: a rotation (right-handed to right-handed), so the
// gyro keeps its sense, while the acceleration is also negated (push -> gravity) and scaled to G.
void input_motion_axes(const float a[3], const float g[3], double acc[3], double gyro[3]) {
    acc[0] = -a[0] / SDL_STANDARD_GRAVITY;
    acc[1] = a[2] / SDL_STANDARD_GRAVITY;
    acc[2] = -a[1] / SDL_STANDARD_GRAVITY;
    gyro[0] = g[0];
    gyro[1] = -g[2];
    gyro[2] = g[1];
}

// Under lock: (re)enable the sensors when the open gamepad changed; 1 if it has both and they are on.
static int sensors_ready(void) {
    SDL_JoystickID id = SDL_GetGamepadID(pad);
    if (id == sensor_pad) return sensor_ok;
    sensor_pad = id;
    // Nothing drains the SDL event queue: no event per sample (the data still updates, SDL_SendJoystickSensor)
    SDL_SetEventEnabled(SDL_EVENT_GAMEPAD_SENSOR_UPDATE, false);
    sensor_ok =SDL_GamepadHasSensor(pad, SDL_SENSOR_GYRO) && SDL_GamepadHasSensor(pad, SDL_SENSOR_ACCEL) &&
                SDL_SetGamepadSensorEnabled(pad, SDL_SENSOR_GYRO, true) &&
                SDL_SetGamepadSensorEnabled(pad, SDL_SENSOR_ACCEL, true);
    if (sensor_ok) rt_log("input: motion sensors on (gyro %.0f Hz, accelerometer %.0f Hz)",
                          (double)SDL_GetGamepadSensorDataRate(pad, SDL_SENSOR_GYRO),
                          (double)SDL_GetGamepadSensorDataRate(pad, SDL_SENSOR_ACCEL));
    else rt_log("input: \"%s\" has no gyro and accelerometer: the six-axis sensor reads a controller at rest",
                SDL_GetGamepadName(pad));
    return sensor_ok;
}

int input_motion_enabled(void) {
    static int on = -1;
    static unsigned seen;
    unsigned v = cfg_version();
    if (on < 0 || v != seen) {
        seen = v;
        on = cfg_bool("TOTK_MOTION");
    }
    return on;
}

// ---- the mouse as the six-axis sensor (mouse_gyro.c). TOTK_MOUSE_GYRO: 1 on, 0 off, auto (default) on for Splatoon 3.
// While on, the mouse's raw counts (and the input script's MOUSE lines) turn a virtual controller whose six-axis states
// the game reads instead of the gamepad's while the keyboard and mouse are the device used last or the gamepad has no
// gyro; the mouse then leaves the right stick alone. The game turns its camera once a frame by the newest state's
// angular velocity times 1/60 s and by the change of the tilt (mouse_gyro.h, mgyro_frame), so the counts are taken at
// the game's read (input_mouse_gyro_read): every count since the previous read goes into the state it reads then. The
// motion thread keeps a state at rest every 5 ms between reads (mouse_gyro_tick), as a live sensor does.
static MotionFusion *mg_fusion;
static MouseGyro mg;
static PlatMutex mg_lock = PLAT_MUTEX_INIT;   // mg and the times below: the motion thread's rest states, the game's reads
static uint64_t mg_last_push, mg_last_read;   // kern_now_ns of the newest state and of the game's last read, 0 none
static int mg_key_prev, mg_inited, mg_on = -1;
static unsigned mg_on_seen;
static int mg_key = KEY_NONE;
static unsigned mg_key_seen = ~0u;

int input_mouse_gyro_on(void) {
    unsigned v = cfg_version();
    if (mg_on < 0 || v != mg_on_seen) {
        mg_on_seen = v;
        const char *s = cfg_value("TOTK_MOUSE_GYRO");
        int on = !strcmp(s, "1") ? 1 : !strcmp(s, "0") ? 0 : rt_target.family == RT_GAME_SPLATOON3;
        if (on != mg_on) rt_log("input: mouse gyro %s (mouse_gyro = %s)", on ? "on: the mouse turns the six-axis sensor" : "off", s);
        mg_on = on;
    }
    return mg_on && input_motion_enabled();
}

// Splatoon 3's camera turns 2.3933 times the controller's yaw at the game's default motion sensitivity (measured,
// docs/controls.md): what mouse_gyro_cm360 divides by.
#define MG_GAME_YAW_GAIN 2.3933

static void mouse_gyro_cfg(MouseGyroCfg *c) {
    double sens = cfg_double("TOTK_MOUSE_GYRO_SENS"), x = cfg_double("TOTK_MOUSE_GYRO_X"), y = cfg_double("TOTK_MOUSE_GYRO_Y"),
           pitch = cfg_double("TOTK_MOUSE_GYRO_PITCH"), cm360 = cfg_double("TOTK_MOUSE_GYRO_CM360"),
           dpi = cfg_double("TOTK_MOUSE_GYRO_DPI");
    if (cm360 > 0 && dpi > 0) {   // a PC game's sensitivity: cm of mouse travel for a whole turn of the camera at that DPI
        sens = mgyro_cm360_deg_per_count(cm360, dpi, MG_GAME_YAW_GAIN);
        c->deg_per_count = sens < 0.00005 ? 0.00005 : sens > 1 ? 1 : sens;
    } else {
        c->deg_per_count = sens < 0.002 ? 0.002 : sens > 1 ? 1 : sens;
    }
    c->scale_x = x < 0.1 ? 0.1 : x > 4 ? 4 : x;
    c->scale_y = y < 0.1 ? 0.1 : y > 4 ? 4 : y;
    c->pitch_limit_deg = pitch < 10 ? 10 : pitch > 89 ? 89 : pitch;
    c->invert_y = cfg_bool("TOTK_MOUSE_GYRO_INVERT_Y");
    c->upright = !strcmp(cfg_value("TOTK_MOUSE_GYRO_ATTITUDE"), "upright");
}

// The key that levels the virtual controller besides Y (TOTK_MOUSE_GYRO_RECENTER_KEY, a key name; none: only Y does).
static void mouse_gyro_key_get(void) {
    unsigned ver = cfg_version();
    if (ver == mg_key_seen) return;
    mg_key_seen = ver;
    const char *name = cfg_value("TOTK_MOUSE_GYRO_RECENTER_KEY");
    mg_key = KEY_NONE;
    if (*name && !name_matches(name, "none")) {
        for (int k = KEY_A; k < KEY_COUNT && mg_key == KEY_NONE; k++)
            if (input_key_name(k) && name_matches(name, input_key_name(k))) mg_key = k;
        if (mg_key == KEY_NONE) rt_log("input: mouse_gyro_recenter_key: unknown key '%s'", name);
    }
}

// The counts to turn now: the script's one-shots and, while the cursor is captured, the mouse's. Counts that arrive while
// the menu or a text entry has the input are dropped, so none turns the camera when it closes.
static void mouse_gyro_collect(double *dx, double *dy) {
    int32_t x = 0, y = 0, sx = 0, sy = 0;
    if (mgb_on()) {   // the bench's simulated mouse alone (mgyro_bench.c); the real one and the script are dropped
        ikb_mouse_take(&x, &y);
        plat_mutex_lock(&lock);
        script_mouse[0] = script_mouse[1] = 0;
        plat_mutex_unlock(&lock);
        mgb_take(kern_now_ns(), dx, dy);
        return;
    }
    plat_mutex_lock(&lock);
    int blocked = g_block == 1 || g_menu == 1;
    sx = script_mouse[0], sy = script_mouse[1];
    script_mouse[0] = script_mouse[1] = 0;
    plat_mutex_unlock(&lock);
    int live = ikb_captured() && ikb_foreground() && input_cursor_allowed();
    ikb_mouse_take(&x, &y);
    if (blocked) { *dx = *dy = 0; return; }
    *dx = (double)sx + (live ? x : 0);
    *dy = (double)sy + (live ? y : 0);
}

enum { MG_REST_NS = 5000000, MG_STALE_NS = 250000000 };
// The game takes the yaw rate's part about gravity, and part of the rest of it moves its pitch (measured: 0.78 degrees
// for a 48 degree turn with the controller 18 degrees down): the rate goes on the controller's own vertical axis,
// divided by the cosine of the pitch (mouse_gyro.h, yaw_body 2), which turns the camera as far with no pitch.
enum { MG_YAW_BODY = 2 };
#define MG_FRAME_MAX_DEG 30.0   // controller yaw in one frame: 72 degrees of the camera at the game's default sensitivity
// Reads held still at a reversal of the yaw (mgyro_frame_yaw): none. Two removed the error a slow back and forth left
// (0.56 degrees after 5 cycles, none with them) but not that of flicks, and they delay every reversal by 33 ms.
enum { MG_REVERSE_HOLD = 0 };

// Under mg_lock: the settings, the recentre key (or Y) and a sensor restart; the time since the newest state.
static double mouse_gyro_prepare(MouseGyroCfg *cfg, uint64_t now) {
    mouse_gyro_cfg(cfg);
    cfg->yaw_body = mgb_yaw_body(MG_YAW_BODY);
    mouse_gyro_key_get();
    int key = mg_key != KEY_NONE && ikb_foreground() && ikb_down(mg_key);
    int recenter = (key && !mg_key_prev) | (int)__atomic_exchange_n(&mg_recenter_req, 0, __ATOMIC_RELAXED);
    mg_key_prev = key;
    if (__atomic_exchange_n(&mg_restart_req, 0, __ATOMIC_RELAXED)) {
        double followed = mg.followed;   // a running total mouse_native.c reads: it goes on across a restart
        mgyro_reset(&mg, cfg->upright);
        mg.followed = followed;
        motion_restart(mg_fusion);
        mg_last_push = 0;
    }
    if (recenter) mgyro_recenter(&mg);
    double dt = mg_last_push && now > mg_last_push ? (double)(now - mg_last_push) / 1e9 : MG_REST_NS / 1e9;
    return dt > 0.1 ? 0.1 : dt;
}

static void mouse_gyro_push(MotionState *s, uint64_t now) {
    mgb_samples(s, 1, now);
    motion_push(mg_fusion, s, now);
    mg_last_push = now;
}

// Every motion-thread tick (about 4 ms): a state at rest when the newest is 5 ms old, so the sensor stays live between
// the game's reads (200 Hz, as the Switch's). Counts wait for the read; those that come while the game reads nothing
// for 250 ms (a load, a menu of its own) are dropped, so they do not turn the camera when it reads again.
static void mouse_gyro_tick(uint64_t now) {
    if (!mg_inited) {
        mg_fusion = motion_new();
        mgyro_reset(&mg, 0);
        mg_inited = 1;
    }
    plat_mutex_lock(&mg_lock);
    if (!input_mouse_gyro_on()) {
        mg_last_push = mg_last_read = 0;
        mg.carry = 0;
        plat_mutex_unlock(&mg_lock);
        return;
    }
    MouseGyroCfg cfg;
    double dt = mouse_gyro_prepare(&cfg, now);
    if (!mg_last_read || now - mg_last_read > MG_STALE_NS) {
        double dx, dy;
        mouse_gyro_collect(&dx, &dy);
        mg.carry = 0;
    }
    if (!mg_last_push || now - mg_last_push >= MG_REST_NS) {
        MotionState s;
        mgyro_rest(&mg, dt, &s);
        mouse_gyro_push(&s, now);
    }
    plat_mutex_unlock(&mg_lock);
}

// The turn mouse_native.c asked the controller's pitch to make at the next read (mg_lock), and whether it was asked
// since the last read.
#define MG_FOLLOW_DEG 1.0
static double mg_follow_delta;
static int mg_follow_asked;

void input_mouse_gyro_follow(double delta_deg) {
    plat_mutex_lock(&mg_lock);
    mg_follow_delta = delta_deg, mg_follow_asked = 1;
    plat_mutex_unlock(&mg_lock);
}

double input_mouse_gyro_followed(double *pitch_deg) {
    plat_mutex_lock(&mg_lock);
    double v = mg.followed;
    *pitch_deg = mg.pitch * 180.0 / M_PI;
    plat_mutex_unlock(&mg_lock);
    return v;
}

int input_mouse_gyro_read(MotionState *out, int max, uint64_t now) {
    plat_mutex_lock(&mg_lock);
    if (mg_inited && input_mouse_gyro_on()) {
        MouseGyroCfg cfg;
        double dt = mouse_gyro_prepare(&cfg, now), dx, dy;
        mouse_gyro_collect(&dx, &dy);
        // a frame's turn modulo a whole turn (measured: 2400 counts in one frame turned it 130 degrees the other way):
        // more than MG_FRAME_MAX_DEG of controller yaw waits for the next read; a reversal waits MG_REVERSE_HOLD reads
        dx = mgyro_frame_yaw(&mg, dx, MG_FRAME_MAX_DEG / (cfg.deg_per_count * cfg.scale_x), mgb_reverse_hold(MG_REVERSE_HOLD));
        // the turn mouse_native.c asked for since the last read, toward a pitch at least 10 degrees inside the limit,
        // so the mouse always has room to tilt the controller further
        MouseGyroFollow follow = {.delta_deg = mg_follow_delta, .rate_deg = mg_follow_asked ? MG_FOLLOW_DEG : 0,
                                  .span_deg = cfg.pitch_limit_deg - 10 > 0 ? cfg.pitch_limit_deg - 10 : 0};
        mg_follow_asked = 0;
        MotionState s;
        mgyro_frame(&mg, &cfg, dx, dy, &follow, 1.0 / MOUSE_GYRO_GAME_HZ, dt, &s);
        mouse_gyro_push(&s, now);
        mg_last_read = now;
    }
    int n = mg_fusion ? motion_read(mg_fusion, out, max, now) : 0;
    plat_mutex_unlock(&mg_lock);
    return n;
}

int input_motion_is_mouse(const MotionFusion *m) { return m && m == mg_fusion; }

double input_mouse_gyro_deg_per_count(void) {
    MouseGyroCfg c;
    mouse_gyro_cfg(&c);
    return c.deg_per_count;
}

// The sensor the game reads (ov_input.c six_fill): the mouse's virtual one while the mouse gyro is on and the keyboard and
// mouse are the device used last or the gamepad has no gyro; else the gamepad's. NULL: motion is off.
MotionFusion *input_motion_source(void) {
    if (!input_motion_enabled()) return NULL;
    if (input_mouse_gyro_on() && mg_fusion &&
        (input_kbm_last() || !__atomic_load_n(&pad_gyro_live, __ATOMIC_RELAXED) || mgb_on()))
        return mg_fusion;
    return motion_global();
}

void input_motion_restart(void) {
    motion_restart(motion_global());
    if (mg_fusion) motion_restart(mg_fusion);
    __atomic_store_n(&mg_restart_req, 1, __ATOMIC_RELAXED);
}

// 250 Hz: the gamepads update (reports read, rumble expiry) and the newest gyro and accelerometer sample goes into the
// fusion. Without a gamepad with sensors, or with motion off (TOTK_MOTION=0, live), nothing is fed and the six-axis
// sensor reads at rest. The mouse gyro's samples are made in the same tick.
static void motion_main(void *arg) {
    (void)arg;
    for (;;) {
        plat_wait_ns(4000000);
        float a[3], g[3];
        int have = 0;
        plat_mutex_lock(&lock);
        if (pad && SDL_GamepadConnected(pad)) {
            SDL_UpdateGamepads();
            have = sensors_ready() && SDL_GetGamepadSensorData(pad, SDL_SENSOR_ACCEL, a, 3) &&
                   SDL_GetGamepadSensorData(pad, SDL_SENSOR_GYRO, g, 3);
        }
        plat_mutex_unlock(&lock);
        __atomic_store_n(&pad_gyro_live, have && input_motion_enabled(), __ATOMIC_RELAXED);
        mouse_gyro_tick(kern_now_ns());
        if (!have || !input_motion_enabled()) continue;
        double acc[3], gyro[3];
        input_motion_axes(a, g, acc, gyro);
        motion_feed(motion_global(), acc, gyro, kern_now_ns());
    }
}

void input_motion_start(void) {
    plat_mutex_lock(&lock);
    if (!state) start();
    if (!motion_thread) {
        if (!input_motion_enabled()) rt_log("input: motion off (TOTK_MOTION=0); it can be turned on while the game runs");
        if (state != 1) motion_thread = -1;
        else {
            if (!plat_thread_spawn(motion_main, NULL, "motion", 0)) rt_fatal("input: cannot start the motion thread");
            motion_thread = 1;
        }
    }
    plat_mutex_unlock(&lock);
}
